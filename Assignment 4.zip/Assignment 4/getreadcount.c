#include "types.h"
#include "stat.h"
#include "user.h"
#include "syscall.h"

int main(void){
  printf(1,"%d\n",getreadcount()); //returns the count
  exit();
}
